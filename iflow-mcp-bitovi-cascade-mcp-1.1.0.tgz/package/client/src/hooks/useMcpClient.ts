/**
 * React Hook for MCP Client
 * 
 * Provides a React-friendly interface to the BrowserMcpClient.
 */

import { useState, useEffect, useCallback, useRef } from 'react';
import { 
  BrowserMcpClient, 
  AnthropicSamplingProvider,
  BrowserOAuthClientProvider,
  type ConnectionState,
  type ConnectionStatus,
} from '../lib/mcp-client/index.js';
import type { Tool, ServerNotification } from '@modelcontextprotocol/sdk/types.js';

export interface UseMcpClientOptions {
  /** Anthropic API key for sampling */
  anthropicApiKey?: string;
}

export interface UseMcpClientReturn {
  /** Current connection state */
  state: ConnectionState;
  /** Available tools (after connection) */
  tools: Tool[];
  /** Log messages from notifications */
  logs: LogEntry[];
  /** Connect to an MCP server */
  connect: (serverUrl: string) => Promise<void>;
  /** Disconnect from the server */
  disconnect: () => Promise<void>;
  /** Call a tool */
  callTool: (name: string, args: Record<string, unknown>) => Promise<any>;
  /** Set Anthropic API key */
  setAnthropicKey: (key: string) => void;
  /** Clear logs */
  clearLogs: () => void;
  /** Refresh OAuth tokens (for testing refresh flow) */
  refreshTokens: () => Promise<{ success: boolean; providers: string[]; error?: string }>;
}

export interface LogEntry {
  id: string;
  timestamp: Date;
  level: 'info' | 'debug' | 'warning' | 'error';
  message: string;
}

/**
 * Hook to manage MCP client connection and state
 */
export function useMcpClient(options: UseMcpClientOptions = {}): UseMcpClientReturn {
  const clientRef = useRef<BrowserMcpClient | null>(null);
  const [state, setState] = useState<ConnectionState>({ status: 'disconnected' });
  const [tools, setTools] = useState<Tool[]>([]);
  const [logs, setLogs] = useState<LogEntry[]>([]);
  const [anthropicKey, setAnthropicKeyState] = useState(options.anthropicApiKey || '');
  
  // Track if we've already started OAuth callback handling (prevents React Strict Mode double-run)
  const oauthHandledRef = useRef(false);

  // Initialize client on mount
  useEffect(() => {
    console.log('[useMcpClient] 🚀 Hook initializing...');
    console.log('[useMcpClient]   Current URL:', window.location.href);
    console.log('[useMcpClient]   Search params:', window.location.search);
    
    clientRef.current = new BrowserMcpClient();
    
    // Set up status change handler
    const unsubscribe = clientRef.current.onStatusChange((newState) => {
      console.log('[useMcpClient] 📊 Status changed:', newState);
      setState(newState);
    });

    // Set up notification handler
    const unsubNotif = clientRef.current.onNotification((notification) => {
      handleNotification(notification);
    });

    // Check for OAuth callback on mount
    const hasCallback = BrowserMcpClient.hasOAuthCallback();
    console.log('[useMcpClient] 🔍 Has OAuth callback?', hasCallback);
    console.log('[useMcpClient]   URL search params:', window.location.search);
    console.log('[useMcpClient]   All localStorage keys:', Object.keys(localStorage).filter(k => k.startsWith('mcp_')));
    
    // Prevent duplicate handling in React Strict Mode
    if (hasCallback && oauthHandledRef.current) {
      console.log('[useMcpClient] ⏭️ OAuth callback already being handled, skipping...');
      return () => {
        unsubscribe();
        unsubNotif();
      };
    }
    
    if (hasCallback) {
      oauthHandledRef.current = true;
      
      // Extract state parameter from OAuth callback (contains return URL)
      const urlParams = new URLSearchParams(window.location.search);
      const stateParam = urlParams.get('state');
      
      // Get stored server URL from localStorage (fallback)
      const storedUrl = localStorage.getItem('mcp_pending_server_url');
      console.log('[useMcpClient] 📦 Stored server URL:', storedUrl);
      
      // Parse state to get return URL and server URL
      let returnUrl: string | null = null;
      if (stateParam) {
        const stateData = BrowserOAuthClientProvider.decodeState(stateParam);
        if (stateData) {
          returnUrl = stateData.returnUrl;
          console.log('[useMcpClient] 📍 Return URL from state:', returnUrl);
        }
      }
      
      if (storedUrl) {
        console.log('[useMcpClient] ✅ Found stored URL, will auto-connect');
        // Auto-reconnect after OAuth callback
        console.log('[useMcpClient] ⏳ Will auto-connect in 100ms...');
        setTimeout(() => {
          console.log('[useMcpClient] 🔄 Auto-connecting to:', storedUrl);
          if (clientRef.current) {
            clientRef.current.connect(storedUrl).then(() => {
              console.log('[useMcpClient] 🎉 Auto-connect succeeded!');
              localStorage.removeItem('mcp_pending_server_url');
              
              // Navigate to original location if we have it from state
              if (returnUrl) {
                console.log('[useMcpClient] 🧭 Navigating to return URL:', returnUrl);
                // Use window.location to preserve hash and query params
                const returnUrlObj = new URL(returnUrl);
                const currentOrigin = window.location.origin;
                if (returnUrlObj.origin === currentOrigin) {
                  // Same origin - safe to navigate
                  window.history.replaceState({}, '', returnUrlObj.pathname + returnUrlObj.search + returnUrlObj.hash);
                }
              }
              
              // Fetch tools after successful connection
              return clientRef.current!.listTools();
            }).then((toolList) => {
              console.log('[useMcpClient] 📋 Got tools:', toolList.length);
              setTools(toolList);
            }).catch((err) => {
              console.error('[useMcpClient] ❌ Auto-connect failed:', err);
            });
          }
        }, 100);
      } else {
        console.log('[useMcpClient] ⚠️ No stored URL found for OAuth callback!');
        console.log('[useMcpClient]   localStorage contents:', JSON.stringify(Object.fromEntries(
          Object.keys(localStorage).filter(k => k.startsWith('mcp_')).map(k => [k, localStorage.getItem(k)?.substring(0, 50)])
        )));
      }
    } else {
      console.log('[useMcpClient] ℹ️ No OAuth callback detected');
      
      // Priority 1: Try reconnecting to an existing MCP session (browser refresh recovery)
      const reconnectionState = BrowserMcpClient.getSavedReconnectionState();
      if (reconnectionState && !oauthHandledRef.current) {
        oauthHandledRef.current = true;
        console.log('[useMcpClient] 🔄 Found reconnection state, attempting session reconnect:', {
          sessionId: reconnectionState.sessionId,
          lastEventId: reconnectionState.lastEventId,
          serverUrl: reconnectionState.serverUrl,
        });
        setTimeout(() => {
          if (clientRef.current) {
            // Pass sessionId/lastEventId directly to avoid localStorage race
            // with React Strict Mode cleanup (which may clear localStorage
            // between when we read state and when reconnect() runs)
            clientRef.current.reconnect(reconnectionState.serverUrl, {
              sessionId: reconnectionState.sessionId,
              lastEventId: reconnectionState.lastEventId,
            }).then(success => {
              if (success) {
                console.log('[useMcpClient] 🎉 Session reconnected!');
                addLog('info', 'Reconnected to existing session — recovering missed events...');
                return clientRef.current!.listTools();
              } else {
                // Session is gone (server restarted?) — try fresh connect with OAuth tokens
                console.log('[useMcpClient] ⚠️ Session reconnect failed, trying fresh connect...');
                addLog('info', 'Session expired — reconnecting...');
                BrowserMcpClient.clearReconnectionState();
                return clientRef.current!.connect(reconnectionState.serverUrl).then(() => {
                  // connect() may return after OAuth redirect — check if actually connected
                  if (clientRef.current?.getState().status === 'connected') {
                    return clientRef.current!.listTools();
                  }
                  return undefined;
                });
              }
            }).then((toolList) => {
              if (toolList) {
                console.log('[useMcpClient] 📋 Got tools:', toolList.length);
                setTools(toolList);
              }
            }).catch((err) => {
              console.error('[useMcpClient] ❌ Reconnect flow failed:', err);
              BrowserMcpClient.clearReconnectionState();
            });
          }
        }, 100);
      } else {
        // Priority 2: Auto-reconnect using stored OAuth tokens (no active session to resume)
        const storedUrl = localStorage.getItem('mcp_last_server_url');
        if (storedUrl && !oauthHandledRef.current) {
          oauthHandledRef.current = true;
          console.log('[useMcpClient] 🔑 Found stored server URL, attempting auto-reconnect:', storedUrl);
          setTimeout(() => {
            if (clientRef.current) {
              clientRef.current.connect(storedUrl).then(() => {
                console.log('[useMcpClient] 🎉 Auto-reconnect succeeded!');
                return clientRef.current!.listTools();
              }).then((toolList) => {
                console.log('[useMcpClient] 📋 Got tools:', toolList.length);
                setTools(toolList);
              }).catch((err) => {
                console.error('[useMcpClient] ❌ Auto-reconnect failed:', err);
              });
            }
          }, 100);
        }
      }
    }

    return () => {
      unsubscribe();
      unsubNotif();
      // Use close() instead of disconnect() — close() does NOT clear
      // reconnection state from localStorage (needed to survive React
      // Strict Mode remounts and actual browser refresh)
      clientRef.current?.close();
    };
  }, []);

  // Update sampling provider when API key changes
  useEffect(() => {
    if (clientRef.current && anthropicKey) {
      clientRef.current.setSamplingProvider(
        new AnthropicSamplingProvider(anthropicKey)
      );
    }
  }, [anthropicKey]);

  const addLog = useCallback((level: LogEntry['level'], message: string) => {
    setLogs(prev => [...prev, {
      id: crypto.randomUUID(),
      timestamp: new Date(),
      level,
      message,
    }]);
  }, []);

  const handleNotification = useCallback((notification: ServerNotification) => {
    // Handle different notification types
    if (notification.method === 'notifications/message') {
      const params = notification.params as { level?: string; data?: string };
      const level = (params.level || 'info') as LogEntry['level'];
      const message = params.data || JSON.stringify(params);
      addLog(level, message);
    } else if (notification.method === 'notifications/progress') {
      const params = notification.params as { 
        progressToken?: string; 
        progress?: number; 
        total?: number;
        message?: string;
      };
      const msg = params.message || `Progress: ${params.progress}/${params.total}`;
      addLog('info', msg);
    } else {
      // Log unknown notifications
      addLog('debug', `Notification: ${notification.method}`);
    }
  }, [addLog]);

  const connect = useCallback(async (serverUrl: string) => {
    console.log('[useMcpClient] 🔌 connect() called with:', serverUrl);
    
    if (!clientRef.current) {
      console.log('[useMcpClient] ❌ No client ref!');
      return;
    }

    // Store server URL for OAuth callback and auto-reconnect
    console.log('[useMcpClient] 💾 Storing server URL in localStorage');
    localStorage.setItem('mcp_pending_server_url', serverUrl);

    try {
      addLog('info', `Connecting to ${serverUrl}...`);
      
      // Set sampling provider if we have an API key
      if (anthropicKey) {
        clientRef.current.setSamplingProvider(
          new AnthropicSamplingProvider(anthropicKey)
        );
      }

      await clientRef.current.connect(serverUrl);
      
      // If we get here, we're connected (not redirected)
      addLog('info', 'Connected! Fetching tools...');
      
      const toolList = await clientRef.current.listTools();
      setTools(toolList);
      addLog('info', `Found ${toolList.length} tools`);
      
      // Save as last successful server URL for auto-reconnect, clean up pending
      localStorage.setItem('mcp_last_server_url', serverUrl);
      localStorage.removeItem('mcp_pending_server_url');
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Connection failed';
      addLog('error', message);
      throw error;
    }
  }, [anthropicKey, addLog]);

  const disconnect = useCallback(async () => {
    if (!clientRef.current) return;
    
    await clientRef.current.disconnect();
    setTools([]);
    
    // Clear stored OAuth tokens and server URL to prevent auto-reconnect
    clientRef.current.clearTokens();
    localStorage.removeItem('mcp_last_server_url');
    localStorage.removeItem('mcp_pending_server_url');
    // disconnect() in BrowserMcpClient already clears mcp_session_id + mcp_last_event_id
    
    addLog('info', 'Disconnected');
  }, [addLog]);

  const callTool = useCallback(async (name: string, args: Record<string, unknown>) => {
    if (!clientRef.current) {
      throw new Error('Not connected');
    }

    addLog('info', `Calling tool: ${name}`);
    
    try {
      const result = await clientRef.current.callTool(name, args);
      addLog('info', `Tool ${name} completed`);
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Tool call failed';
      addLog('error', `Tool ${name} failed: ${message}`);
      throw error;
    }
  }, [addLog]);

  const setAnthropicKey = useCallback((key: string) => {
    setAnthropicKeyState(key);
    // Store in localStorage for persistence across page reloads
    if (key) {
      localStorage.setItem('mcp_anthropic_key', key);
    } else {
      localStorage.removeItem('mcp_anthropic_key');
    }
  }, []);

  const clearLogs = useCallback(() => {
    setLogs([]);
  }, []);

  const refreshTokens = useCallback(async () => {
    if (!clientRef.current) {
      return { success: false, providers: [], error: 'Not connected' };
    }

    addLog('info', '🔄 Refreshing OAuth tokens...');
    
    try {
      const result = await clientRef.current.refreshTokens();
      
      if (result.success) {
        const providersStr = result.providers.length > 0 
          ? result.providers.join(', ') 
          : 'unknown';
        addLog('info', `✅ Token refresh successful! Providers: ${providersStr}`);
      } else {
        addLog('error', `❌ Token refresh failed: ${result.error}`);
      }
      
      return result;
    } catch (error) {
      const message = error instanceof Error ? error.message : 'Token refresh failed';
      addLog('error', `❌ Token refresh error: ${message}`);
      return { success: false, providers: [], error: message };
    }
  }, [addLog]);

  // Load stored API key on mount
  useEffect(() => {
    const storedKey = localStorage.getItem('mcp_anthropic_key');
    if (storedKey && !anthropicKey) {
      setAnthropicKeyState(storedKey);
    }
  }, []);

  return {
    state,
    tools,
    logs,
    connect,
    disconnect,
    callTool,
    setAnthropicKey,
    clearLogs,
    refreshTokens,
  };
}
