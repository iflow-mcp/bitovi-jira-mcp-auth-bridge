/**
 * Figma Questions Prompt
 *
 * Generates prompts for AI to analyze Figma designs holistically and produce
 * questions organized by frame. Unlike scope analysis (which groups by feature area),
 * this outputs questions in a frame-first format for posting back to Figma.
 */

import type { ScreenAnnotation } from '../../../combined/tools/shared/screen-annotation.js';

/**
 * System prompt for Figma question generation
 */
export const FIGMA_QUESTIONS_SYSTEM_PROMPT = `You are an expert product analyst reviewing Figma designs to identify ambiguities, missing requirements, and clarifying questions.

**CRITICAL RULE - CROSS-SCREEN AWARENESS:**
These screens form a connected flow. If ANY screen shows a behavior (component appearance, positioning, interaction pattern), that DEFINES the behavior for the entire flow. Do NOT ask questions about something that is already visible in another screen. Note: The scope description and Figma components may use different terminology for the same thing - match by function, not name.

**VISUAL DETAILS FILTER (Apply Before EVERY Question):**

Before asking ANY question about a component's appearance, position, or styling, you MUST:

1. **Search ALL screen analyses** for that component type (by function, not just name)
2. **Check if styling is visible**: If ANY screen shows that component with colors, icons, buttons, typography → styling is DEFINED → DO NOT ASK
3. **Check if position is visible**: If ANY screen shows where that component appears on screen → position is DEFINED → DO NOT ASK
4. **Check if behavior is shown**: If ANY screen demonstrates the interaction → behavior is DEFINED → DO NOT ASK

**SKIP questions about things that ARE visually shown in any screen:**
- Component styling (colors, typography, icons, borders)
- Component positioning (where it appears on screen)
- Visual states that are depicted (if a variant is shown, don't ask about its appearance)
- UI elements that are visible (buttons, icons, labels)

HOLISTIC ANALYSIS:
- Review ALL screens together to understand the complete user flow
- Think through how users move between screens
- Identify gaps in the flow, not just individual screen issues
- Each question should be assigned to the MOST RELEVANT screen

SCOPE AWARENESS:
- **PRIORITY**: Context description and designer notes are the primary sources of truth for scope
- If context or notes say a feature is out-of-scope or already implemented, DO NOT ask questions about it
- In screen analyses, look for scope markers:
  * ☐ = In-Scope: Features to implement (ASK questions about these)
  * ✅ = Already Done: Existing features (DO NOT ask questions about these)
  * ❌ = Out-of-Scope: Features to ignore (DO NOT ask questions about these)
- ONLY generate questions about features marked with ☐ (in-scope checkboxes)
- IGNORE all features marked with ✅ (already done) or ❌ (out-of-scope)
- When in doubt about scope, refer to context description and notes first

QUESTION QUALITY:
- Ask about unclear behaviors, edge cases, and missing states
- Focus on what a developer would need to know to implement
- **DO NOT ask about behaviors already visible in ANY screen** - if something is shown in one screen, assume it applies consistently
- Avoid questions about features explicitly marked as out-of-scope or already done
- Be specific and actionable

QUESTION ASSIGNMENT:
- Assign each question to the screen where the answer would most impact implementation
- If a question spans multiple screens, assign to the screen where the issue first appears
- Every question MUST be assigned to a specific screen - do NOT use a "General" category
- If no screen is a perfect fit, pick the closest match - it's okay to assign cross-cutting questions to the most relevant screen
- Questions that would have the SAME answer regardless of which screen they're on should only appear once

OUTPUT REQUIREMENT:
- Output ONLY the markdown in the specified format
- Every screen with questions gets its own section (but some screens may have NO questions if other screens already show the behavior)
- Screens with no questions should be omitted
- Do NOT include explanations, prefaces, or process notes`;

/**
 * Maximum tokens for question generation
 */
export const FIGMA_QUESTIONS_MAX_TOKENS = 8000;

/**
 * Screen info for prompt generation
 */
export interface ScreenInfo {
  nodeId: string;
  name: string;
  url: string;
  analysisContent: string;
}

/**
 * Generate the Figma questions prompt
 *
 * @param screens - Array of screen info with analysis content
 * @param contextDescription - Optional additional context from user
 * @param commentContexts - Optional existing comments for context
 * @param scopeAnalysis - Optional scope analysis (cross-screen synthesis)
 * @returns Complete prompt for question generation
 */
export function generateFigmaQuestionsPrompt(
  screens: ScreenInfo[],
  contextDescription?: string,
  commentContexts?: ScreenAnnotation[],
  scopeAnalysis?: string
): string {
  // Build context section
  const contextSection = contextDescription?.trim()
    ? `## Context Description

**SCOPE GUIDANCE (Primary Source of Truth):**

<context>
${contextDescription.trim()}
</context>

**Use this context to understand:**
- What features are in-scope vs out-of-scope
- What features are already implemented (don't ask questions about these)
- What features should be ignored or deferred
- Project priorities and constraints

**Context ALWAYS WINS:**
- If context says a feature is out-of-scope or already done, skip questions about it entirely
- If context says a feature is in-scope, focus questions on unclear implementation details
- When in doubt about whether to ask a question, refer to context first

---

`
    : '';

  // Build existing comments and notes section
  const commentsSection =
    commentContexts && commentContexts.length > 0
      ? `## Existing Comments and Notes

**IMPORTANT**: The following comments, notes, and annotations already exist on these designs.
- **Notes provide scope guidance** - they may specify what's in-scope, out-of-scope, already implemented, or should be ignored. Respect these boundaries when generating questions.
- **Comments contain existing questions or clarifications** - DO NOT duplicate these
- If a topic is already covered, skip it entirely

${commentContexts.map((ctx) => `### ${ctx.screenName}\n\n${ctx.markdown}`).join('\n\n')}

---

`
      : '';

  // Log when comments/notes are included in prompt
  if (commentContexts && commentContexts.length > 0) {
    console.log(`  📝 Including ${commentContexts.length} context(s) in question generation prompt`);
  }

  // Build scope analysis section (cross-screen synthesis)
  const scopeAnalysisSection = scopeAnalysis?.trim()
    ? `## Scope Analysis (Cross-Screen Synthesis)

**IMPORTANT**: This scope analysis was generated by reviewing ALL screens together. It identifies:
- Features grouped by workflow area
- Which screens show each feature
- ☐ In-scope features, ✅ already done, ❌ out-of-scope, ❓ existing questions

**Use this to understand what's ALREADY DEFINED across screens.**
If a behavior is described here as visible in any screen, do NOT ask questions about it.

${scopeAnalysis.trim()}

---

`
    : '';

  // Build screen analyses section
  const screensSection = screens
    .map(
      (screen) => `### [${screen.name}](${screen.url})

**Node ID:** ${screen.nodeId}

${screen.analysisContent}

---`
    )
    .join('\n\n');

  return `${contextSection}${commentsSection}${scopeAnalysisSection}## Screen Analyses

${screensSection}

## Instructions

1. **FIRST: Catalog defined behaviors** - Scan ALL screens and note what IS already shown (component styles, positions, interactions). These are ANSWERED - do not ask about them.
2. **Review context description** - Understand what's in-scope, out-of-scope, and already implemented
3. **Review notes for scope guidance** - Notes on screens specify what to focus on or ignore
4. **Review scope markers in analyses** - Look for ☐ (in-scope), ✅ (already done), ❌ (out-of-scope) markers
5. **ONLY ask questions about ☐ in-scope features** - Skip all ✅ and ❌ features entirely
6. **Identify TRUE gaps** - Only ask about behaviors not shown in ANY screen
7. **Check existing comments** - Skip questions already asked in comments
8. **Assign questions to screens** - Each question goes under the most relevant screen
9. **Avoid duplicates** - Don't repeat yourself or existing comments/notes

**CRITICAL FILTERING RULE:**
- If a feature is marked with ✅ (Already Done) anywhere in the analysis, DO NOT generate questions about it
- If a feature is marked with ❌ (Out-of-Scope), DO NOT generate questions about it
- ONLY generate questions for features marked with ☐ (In-Scope checkboxes)
- Example: If you see "✅ Already Done: Case management interface", skip ALL questions about case management

## Output Format

\`\`\`markdown
## Figma Analysis Questions

### [Screen Name](figma-url-with-node-id)

- ❓ Question about this screen
- ❓ Another question

### [Another Screen](figma-url-with-node-id)

- ❓ Question about this screen
\`\`\`

**CRITICAL**: 
- Use the exact screen name and URL from the analyses above
- Only include screens that have questions
- Every question MUST be under a specific screen heading - no "General" section
- Output ONLY the markdown, no explanations`;
}

/**
 * Parsed question with frame association
 */
export interface ParsedQuestion {
  text: string;
  frameNodeId?: string;
  frameName?: string;
  frameUrl?: string;
}

/**
 * Parsed questions grouped by frame
 */
export interface ParsedFigmaQuestions {
  byFrame: Map<string, ParsedQuestion[]>; // nodeId -> questions
  general: ParsedQuestion[];
}

/**
 * Parse questions from Figma questions markdown output
 *
 * Extracts questions grouped by frame from the AI-generated markdown.
 * Parses node-id from the URL in each heading.
 *
 * @param markdown - The markdown output from AI
 * @returns Parsed questions grouped by frame
 */
export function parseFigmaQuestions(markdown: string): ParsedFigmaQuestions {
  const result: ParsedFigmaQuestions = {
    byFrame: new Map(),
    general: [],
  };

  const lines = markdown.split('\n');

  // Patterns
  const headingPattern = /^###\s+\[([^\]]+)\]\(([^)]+)\)\s*$/;
  const generalHeadingPattern = /^###\s+General\s*$/i;
  const questionPattern = /^[-*]?\s*❓\s*(.+)$/;
  const nodeIdPattern = /node-id=(\d+[:-]\d+)/;

  let currentFrame: { nodeId: string; name: string; url: string } | null = null;
  let isGeneralSection = false;

  for (const line of lines) {
    const trimmedLine = line.trim();

    // Check for General heading
    if (generalHeadingPattern.test(trimmedLine)) {
      currentFrame = null;
      isGeneralSection = true;
      continue;
    }

    // Check for frame heading with link
    const headingMatch = trimmedLine.match(headingPattern);
    if (headingMatch) {
      const [, name, url] = headingMatch;
      const nodeIdMatch = url.match(nodeIdPattern);

      if (nodeIdMatch) {
        // Convert URL format (123-456) to API format (123:456)
        const nodeId = nodeIdMatch[1].replace('-', ':');
        currentFrame = { nodeId, name, url };
        isGeneralSection = false;

        if (!result.byFrame.has(nodeId)) {
          result.byFrame.set(nodeId, []);
        }
      }
      continue;
    }

    // Check for questions
    const questionMatch = trimmedLine.match(questionPattern);
    if (questionMatch) {
      const questionText = questionMatch[1].trim();

      if (isGeneralSection) {
        result.general.push({ text: questionText });
      } else if (currentFrame) {
        const questions = result.byFrame.get(currentFrame.nodeId) || [];
        questions.push({
          text: questionText,
          frameNodeId: currentFrame.nodeId,
          frameName: currentFrame.name,
          frameUrl: currentFrame.url,
        });
        result.byFrame.set(currentFrame.nodeId, questions);
      }
    }
  }

  return result;
}

/**
 * Convert parsed questions to flat array for posting
 *
 * @param parsed - Parsed questions from parseFigmaQuestions
 * @returns Flat array of questions with frame associations
 */
export function flattenParsedQuestions(parsed: ParsedFigmaQuestions): ParsedQuestion[] {
  const questions: ParsedQuestion[] = [];

  // Add frame-specific questions
  for (const frameQuestions of parsed.byFrame.values()) {
    questions.push(...frameQuestions);
  }

  // Add general questions
  questions.push(...parsed.general);

  return questions;
}
