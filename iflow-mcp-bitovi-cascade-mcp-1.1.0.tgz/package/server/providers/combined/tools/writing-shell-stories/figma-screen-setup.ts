/**
 * Figma Screen Setup Helper
 * 
 * Shared utility for setting up Figma screen data and notes.
 * This is FAST (no image downloads or AI analysis) and should be run every time.
 * 
 * Used by both write-shell-stories and write-next-story to:
 * - Fetch Jira epic and extract Figma URLs
 * - Extract epic context (excluding Shell Stories section)
 * - Fetch Figma file metadata (frames and notes)
 * - Associate notes with screens spatially
 * - Write notes files to temp directory
 * - Generate screens.yaml
 * 
 * The slow part (image download + AI analysis) is handled separately by screen-analyses-workflow.
 */

import * as path from 'path';
import * as fs from 'fs/promises';
import type { AtlassianClient } from '../../../atlassian/atlassian-api-client.js';
import type { FigmaClient } from '../../../figma/figma-api-client.js';
import type { FigmaNodeMetadata } from '../../../figma/figma-helpers.js';
import { 
  parseFigmaUrl, 
  fetchFigmaNode,
  fetchFigmaNodesBatch,
  getFramesAndNotesForNode,
  convertNodeIdToApiFormat,
  FigmaUnrecoverableError
} from '../../../figma/figma-helpers.js';
import { resolveCloudId, getJiraIssue, handleJiraAuthError } from '../../../atlassian/atlassian-helpers.js';
import { 
  countADFSectionsByHeading,
  type ADFNode,
  type ADFDocument,
} from '../../../atlassian/markdown-converter.js';
import { buildIssueContext } from '../shared/issue-context-builder.js';
import { extractFigmaUrlsFromADF } from '../../../atlassian/adf-utils.js';
import type { JiraIssue } from '../../../atlassian/types.js';
import { associateNotesWithFrames, type Screen } from './screen-analyzer.js';
import { generateScreensYaml } from './yaml-generator.js';
// import { writeNotesForScreen } from './note-text-extractor.js';

/**
 * Fetches Figma metadata (frames and notes) from multiple Figma URLs using batched requests.
 * 
 * This function performs semi-recursive accumulation of frames and notes with batching optimization:
 * - Groups URLs by file key for efficient batching
 * - Makes one batch API request per file key (instead of N sequential requests)
 * - For each node, calls getFramesAndNotesForNode() which:
 *   - If node is a CANVAS: Returns all direct child FRAME nodes (one level of recursion)
 *   - If node is a FRAME: Returns that single frame
 *   - Also extracts all Note instances at any level within the node
 * - Accumulates all frames and notes across multiple URLs
 * - Stores the first valid file key for later image download operations
 * 
 * Rate limit optimization: Reduces N requests to 1-3 requests (depending on file key distribution)
 * 
 * @param figmaUrls - Array of Figma URLs to process
 * @param figmaClient - Figma API client with auth
 * @returns Object containing accumulated metadata and the file key
 */
export async function fetchFigmaMetadataFromUrls(
  figmaUrls: string[],
  figmaClient: FigmaClient
): Promise<{ allFramesAndNotes: Array<{ url: string; metadata: FigmaNodeMetadata[] }>; figmaFileKey: string; nodesDataMap: Map<string, any> }> {
  const allFramesAndNotes: Array<{ url: string; metadata: FigmaNodeMetadata[] }> = [];
  const nodesDataMap = new Map<string, any>(); // Store full node data for each frame
  let figmaFileKey = '';
  
  // Phase 1: Group URLs by fileKey and validate
  const urlsByFileKey = new Map<string, Array<{ url: string; nodeId: string; index: number }>>();
  
  for (let i = 0; i < figmaUrls.length; i++) {
    const figmaUrl = figmaUrls[i];
    
    // Parse URL
    const urlInfo = parseFigmaUrl(figmaUrl);
    if (!urlInfo) {
      console.log('    ⚠️  Invalid Figma URL format, skipping');
      continue;
    }
    
    if (!urlInfo.nodeId) {
      console.log('    ⚠️  Figma URL missing nodeId, skipping');
      continue;
    }
    
    const apiNodeId = convertNodeIdToApiFormat(urlInfo.nodeId);
    
    // Store first valid file key for image downloads later
    if (!figmaFileKey) {
      figmaFileKey = urlInfo.fileKey;
    }
    
    // Group by file key for batching
    if (!urlsByFileKey.has(urlInfo.fileKey)) {
      urlsByFileKey.set(urlInfo.fileKey, []);
    }
    urlsByFileKey.get(urlInfo.fileKey)!.push({ url: figmaUrl, nodeId: apiNodeId, index: i });
  }
  
  // Phase 2: Batch fetch per fileKey
  for (const [fileKey, urlInfos] of urlsByFileKey) {
    try {
      // ✅ Single batch request for all nodes in this file
      const nodeIds = urlInfos.map(u => u.nodeId);
      const nodesMap = await fetchFigmaNodesBatch(figmaClient, fileKey, nodeIds);
      
      // Phase 3: Process each node to extract frames/notes
      for (const { url, nodeId } of urlInfos) {
        const nodeData = nodesMap.get(nodeId);
        
        if (!nodeData) {
          console.log(`    ⚠️  Node ${nodeId} not found in response`);
          continue;
        }
        
        // Semi-recursive extraction: getFramesAndNotesForNode() extracts:
        // - For CANVAS nodes: all direct child FRAME nodes (one level recursion)
        // - For SECTION nodes: all direct child FRAME nodes (expanded from SECTION)
        // - For FRAME nodes: just that single frame
        // - Notes at any level within the node
        const framesAndNotes = getFramesAndNotesForNode({ document: nodeData }, nodeId);
        
        // Store full node data for each extracted frame
        framesAndNotes.forEach(item => {
          if (item.type === 'FRAME') {
            // For frames, we need to find the actual frame node data
            // If nodeData itself is a FRAME, use it; otherwise find in children
            if (nodeData.type === 'FRAME' && nodeData.id === item.id) {
              nodesDataMap.set(item.id, nodeData);
            } else if (nodeData.children) {
              // Recursively search for frame in children
              const findFrame = (node: any): any => {
                if (node.id === item.id) return node;
                if (node.children) {
                  for (const child of node.children) {
                    const found = findFrame(child);
                    if (found) return found;
                  }
                }
                return null;
              };
              const frameNode = findFrame(nodeData);
              if (frameNode) {
                nodesDataMap.set(item.id, frameNode);
              }
            }
          }
        });
        
        // Check if the original URL pointed to a SECTION - if so, tag all extracted frames
        if (nodeData.type === 'SECTION') {
          console.log(`    📦 Tagging ${framesAndNotes.length} frames with SECTION context: "${nodeData.name}"`);
          framesAndNotes.forEach(frame => {
            if (frame.type === 'FRAME') {
              (frame as any).sectionName = nodeData.name;
              (frame as any).sectionId = nodeData.id;
            }
          });
        }
        
        // Accumulate into array (maintains same structure as before)
        allFramesAndNotes.push({
          url,
          metadata: framesAndNotes
        });
      }
      
    } catch (error: any) {
      console.log(`    ⚠️  Error fetching batch from ${fileKey}: ${error.message}`);
      
      // Unrecoverable errors (403, 429) should be immediately re-thrown
      // These already have user-friendly messages from the helper functions
      if (error instanceof FigmaUnrecoverableError) {
        throw error;
      }
      
      // For other errors, continue trying remaining file keys
    }
  }
  
  return { allFramesAndNotes, figmaFileKey, nodesDataMap };
}

/**
 * Separates frames and notes from combined Figma metadata.
 * 
 * This function accumulates frames and notes from multiple Figma nodes:
 * - When a CANVAS node is passed to getFramesAndNotesForNode(), it returns all child frames
 * - When a FRAME node is passed to getFramesAndNotesForNode(), it returns that single frame
 * - Notes (INSTANCE type with name "Note") can appear at any level
 * 
 * This helper consolidates all accumulated metadata into separate arrays for processing.
 * Deduplicates frames and notes by ID to handle cases where:
 * - Epic has both a CANVAS/SECTION URL and individual frame URLs
 * - SECTION expansion returns frames that are also directly referenced
 * 
 * @param allFramesAndNotes - Array of metadata from potentially multiple Figma URLs/nodes
 * @returns Object containing separate arrays of frames and notes
 */
export function separateFramesAndNotes(
  allFramesAndNotes: Array<{ url: string; metadata: FigmaNodeMetadata[] }>
): { frames: FigmaNodeMetadata[]; notes: FigmaNodeMetadata[] } {
  const frameMap = new Map<string, FigmaNodeMetadata>();
  const noteMap = new Map<string, FigmaNodeMetadata>();
  
  for (const item of allFramesAndNotes) {
    // Frames are type === "FRAME"
    const frames = item.metadata.filter(n => n.type === 'FRAME');
    
    // Notes are type === "INSTANCE" with name === "Note"
    const notes = item.metadata.filter(n => 
      n.type === 'INSTANCE' && n.name === 'Note'
    );
    
    // Deduplicate by ID
    for (const frame of frames) {
      if (!frameMap.has(frame.id)) {
        frameMap.set(frame.id, frame);
      }
    }
    
    for (const note of notes) {
      if (!noteMap.has(note.id)) {
        noteMap.set(note.id, note);
      }
    }
  }
  
  return { 
    frames: Array.from(frameMap.values()), 
    notes: Array.from(noteMap.values()) 
  };
}

// extractFigmaUrlsFromADF is now imported from adf-utils.ts

/**
 * Result of processing Figma URLs
 */
export interface ProcessFigmaUrlsResult {
  /** All frames found across URLs */
  allFrames: FigmaNodeMetadata[];
  /** All notes found across URLs */
  allNotes: FigmaNodeMetadata[];
  /** Screens with spatially associated notes */
  screens: ScreenWithNotes[];
  /** Note URLs not spatially associated with any frame */
  unassociatedNotes: string[];
  /** File key (for image downloads) */
  figmaFileKey: string;
  /** Map of frameId -> full node data for semantic XML */
  nodesDataMap: Map<string, any>;
  /** Input Figma URLs */
  figmaUrls: string[];
}

/**
 * Process Figma URLs into frames, notes, and screens with spatial associations
 * 
 * Shared logic used by both:
 * - setupFigmaScreens (processes URLs from Jira epic)
 * - analyze-figma-scope (processes URLs directly from input)
 * 
 * Steps:
 * 1. Batch fetch Figma metadata from URLs
 * 2. Separate frames and notes with deduplication
 * 3. Spatially associate notes with frames
 * 
 * @param figmaUrls - Figma URLs to process
 * @param figmaClient - Authenticated Figma API client
 * @returns Frames, notes, screens with associations, and file key
 */
export async function processFigmaUrls(
  figmaUrls: string[],
  figmaClient: FigmaClient
): Promise<ProcessFigmaUrlsResult> {
  // Step 1: Batch fetch metadata
  const { allFramesAndNotes, figmaFileKey, nodesDataMap } = await fetchFigmaMetadataFromUrls(figmaUrls, figmaClient);
  
  // Step 2: Separate and deduplicate
  const { frames: allFrames, notes: allNotes } = separateFramesAndNotes(allFramesAndNotes);
  
  console.log(`    Found ${allFrames.length} frames, ${allNotes.length} notes`);
  
  // Step 3: Spatially associate notes with frames
  const baseUrl = figmaUrls[0]?.split('?')[0] || '';
  const { screens, unassociatedNotes } = associateNotesWithFrames(
    allFrames,
    allNotes,
    baseUrl
  );
  
  return {
    allFrames,
    allNotes,
    screens,
    unassociatedNotes,
    figmaFileKey,
    nodesDataMap,
    figmaUrls,
  };
}

/**
 * Screen with spatially associated note texts
 * Extends Screen to add notes text array
 */
export interface ScreenWithNotes extends Screen {
  // Inherits all fields from Screen
  // notes: string[] is already in Screen
}

/**
 * Parameters for Figma screen setup
 */
export interface FigmaScreenSetupParams {
  epicKey: string;               // Jira epic key
  atlassianClient: AtlassianClient;  // Atlassian API client with auth in closure
  figmaClient: FigmaClient;          // Figma API client with auth in closure
  debugDir: string | null;       // Debug directory for artifacts (null if not in DEV mode)
  cloudId?: string;              // Optional explicit cloud ID
  siteName?: string;             // Optional site name
  notify?: (message: string) => Promise<void>;  // Optional progress callback
}

/**
 * Result of Figma screen setup
 */
export interface FigmaScreenSetupResult {
  screens: ScreenWithNotes[];
  allFrames: FigmaNodeMetadata[];
  allNotes: FigmaNodeMetadata[];
  figmaFileKey: string;          // File key for image downloads
  nodesDataMap: Map<string, any>;  // Map of frameId -> full node data for semantic XML
  yamlContent: string;           // Generated screens.yaml content
  yamlPath?: string;             // Path to screens.yaml (only in DEV mode)
  epicWithoutShellStoriesMarkdown: string;   // Epic content excluding Shell Stories
  epicWithoutShellStoriesAdf: ADFNode[];           // Epic content excluding Shell Stories
  epicDescriptionAdf: ADFDocument;     // Full epic description (ADF)
  shellStoriesAdf: ADFNode[];          // Shell Stories section (if exists)
  
  figmaUrls: string[];           // Extracted Figma URLs
  cloudId: string;               // Resolved cloud ID
  siteName: string;              // Resolved site name
  siteUrl: string;               // Site URL (e.g., https://mycompany.atlassian.net)
  projectKey: string;            // Project key from epic
  epicKey: string;               // Epic key
  epicUrl: string;               // Epic URL
}

/**
 * Setup Figma screens with notes
 * 
 * Fetches epic, extracts Figma URLs and context, fetches Figma metadata, 
 * associates notes with frames, and writes note files.
 * This is fast and should be done every time (even when using cached analysis files).
 * 
 * @param params - Configuration including epic key, tokens, and temp directory
 * @returns Screen data with notes, frames, notes metadata, epic context, and file key
 */
export async function setupFigmaScreens(
  params: FigmaScreenSetupParams
): Promise<FigmaScreenSetupResult> {
  const { epicKey, atlassianClient, figmaClient, debugDir, cloudId, siteName, notify } = params;
  
  // ==========================================
  // Step 1: Fetch epic and extract Figma URLs
  // ==========================================
  if (notify) {
    await notify('Fetching epic from Jira...');
  }
  
  // Resolve cloud ID (use explicit cloudId/siteName or first accessible site)
  const siteInfo = await resolveCloudId(atlassianClient, cloudId, siteName);
  
  // Fetch the epic issue
  const issueResponse = await getJiraIssue(atlassianClient, siteInfo.cloudId, epicKey, undefined);
  await handleJiraAuthError(issueResponse, 'Fetch epic');
  
  const issue = await issueResponse.json() as JiraIssue;
  


  // ==========================================
  // Step 2: Extract epic context (excluding Shell Stories)
  // ==========================================
  if (notify) {
    await notify('Extracting epic content...');
  }

  const projectKey = issue.fields?.project?.key;
  if (!projectKey) {
    throw new Error(`Epic ${epicKey} has no project key.`);
  }
  
  // Extract Figma URLs from epic description
  const description = issue.fields?.description;
  if (!description) {
    throw new Error(`Epic ${epicKey} has no description. Please add Figma design URLs to the epic description.`);
  }
  
  const figmaUrls = extractFigmaUrlsFromADF(description);
  console.log(`  Found ${figmaUrls.length} Figma URLs`);
  
  if (figmaUrls.length === 0) {
    throw new Error(`No Figma URLs found in epic ${epicKey}. Please add Figma design links to the epic description.`);
  }
  
  // Check for multiple Shell Stories sections
  const shellStoriesCount = countADFSectionsByHeading(description.content || [], 'shell stories');
  if (shellStoriesCount > 1) {
    throw new Error(`Epic ${epicKey} contains ${shellStoriesCount} "## Shell Stories" sections. Please consolidate into one section.`);
  }
  
  // Extract epic context and Shell Stories section using shared helper
  const issueContext = buildIssueContext(
    [{ key: epicKey, fields: { summary: issue.fields?.summary || '', description } }],
    { excludeSections: ['Shell Stories'] }
  );
  
  const epicWithoutShellStoriesAdf = issueContext.adf;
  const epicWithoutShellStoriesMarkdown = issueContext.markdown;
  const shellStoriesExtracted = issueContext.extractedSections.get('Shell Stories');
  const shellStoriesAdf = shellStoriesExtracted?.adf || [];
  
  console.log(`    Epic context: ${epicWithoutShellStoriesAdf.length} ADF nodes`);
  console.log(`    Shell stories: ${shellStoriesAdf.length} ADF nodes`);
  
  // ==========================================
  // Step 3: Process Figma URLs (fetch, separate, associate)
  // ==========================================
  const {
    allFrames,
    allNotes,
    screens,
    unassociatedNotes,
    figmaFileKey,
    nodesDataMap,
  } = await processFigmaUrls(figmaUrls, figmaClient);
  
  // ==========================================
  // Step 4: Generate screens.yaml content
  // ==========================================
  const yamlContent = generateScreensYaml(screens, unassociatedNotes);
  let yamlPath: string | undefined;
  
  // Only write to file in DEV mode
  if (debugDir) {
    if (notify) {
      await notify('Saving preparation data...');
    }
    
    yamlPath = path.join(debugDir, 'screens.yaml');
    await fs.writeFile(yamlPath, yamlContent, 'utf-8');
  }
  
  // Construct epic URL
  const epicUrl = `https://${siteInfo.siteName}.atlassian.net/browse/${epicKey}`;
  
  return {
    screens,
    allFrames,
    allNotes,
    figmaFileKey,
    nodesDataMap,
    yamlContent,
    yamlPath,
    epicWithoutShellStoriesMarkdown,
    epicWithoutShellStoriesAdf,
    epicDescriptionAdf: description,
    shellStoriesAdf,
    figmaUrls,
    cloudId: siteInfo.cloudId,
    siteName: siteInfo.siteName,
    siteUrl: siteInfo.siteUrl,
    projectKey,
    epicKey,
    epicUrl
  };
}
