/**
 * Unit tests for Google Docs Setup
 * 
 * Tests the setupGoogleDocsContext() orchestration function with mocked dependencies.
 */

import { describe, test, expect, jest, beforeEach, afterEach } from '@jest/globals';
import type { ADFDocument } from '../../../atlassian/markdown-converter.js';
import type { GoogleClient } from '../../../google/google-api-client.js';
import type { GenerateTextFn } from '../../../../llm-client/types.js';

// We'll test the public interface once implemented
// For now, define expected types based on data-model.md

describe('setupGoogleDocsContext', () => {
  // Mock dependencies
  let mockGoogleClient: GoogleClient;
  let mockGenerateText: GenerateTextFn;

  beforeEach(() => {
    // Reset mocks before each test
    mockGoogleClient = {
      fetch: jest.fn<(url: string, options?: RequestInit) => Promise<Response>>().mockResolvedValue({
        ok: true,
        status: 200,
        json: jest.fn<() => Promise<any>>().mockResolvedValue({
          id: 'doc123',
          name: 'Test Document',
          mimeType: 'application/vnd.google-apps.document',
          modifiedTime: '2024-01-01T00:00:00Z',
        }),
        text: jest.fn<() => Promise<string>>().mockResolvedValue(''),
      } as unknown as Response),
      authType: 'oauth' as const,
    } as unknown as GoogleClient;

    mockGenerateText = jest.fn<() => Promise<{ text: string }>>().mockResolvedValue({
      text: JSON.stringify({
        documentType: 'requirements',
        toolScores: [
          { toolId: 'analyze-feature-scope', overallScore: 8, summary: 'Highly relevant' },
          { toolId: 'write-shell-stories', overallScore: 7, summary: 'Relevant' },
          { toolId: 'write-next-story', overallScore: 6, summary: 'Somewhat relevant' },
        ],
      }),
    }) as unknown as GenerateTextFn;
  });

  afterEach(() => {
    jest.clearAllMocks();
  });

  test('returns empty result when no Google Docs URLs in ADF', async () => {
    // Import dynamically to allow for module mocking
    const { setupGoogleDocsContext } = await import('./google-docs-setup.js');

    const adf: ADFDocument = {
      version: 1,
      type: 'doc',
      content: [
        {
          type: 'paragraph',
          content: [{ type: 'text', text: 'No links here' }],
        },
      ],
    };

    const result = await setupGoogleDocsContext({
      epicAdf: adf,
      googleClient: mockGoogleClient,
      generateText: mockGenerateText,
    });

    expect(result.documents).toHaveLength(0);
    expect(result.byRelevance.analyzeScope).toHaveLength(0);
    expect(result.byRelevance.writeStories).toHaveLength(0);
    expect(result.byRelevance.writeNextStory).toHaveLength(0);
  });

  test('returns empty result with warning when googleClient is undefined', async () => {
    const { setupGoogleDocsContext } = await import('./google-docs-setup.js');

    const adf: ADFDocument = {
      version: 1,
      type: 'doc',
      content: [
        {
          type: 'paragraph',
          content: [
            {
              type: 'inlineCard',
              attrs: { url: 'https://docs.google.com/document/d/doc123/edit' },
            },
          ],
        },
      ],
    };

    const result = await setupGoogleDocsContext({
      epicAdf: adf,
      googleClient: undefined,
      generateText: mockGenerateText,
    });

    expect(result.documents).toHaveLength(0);
    expect(result.warnings).toBeDefined();
    expect(result.warnings?.length).toBeGreaterThan(0);
    expect(result.warnings?.[0]).toContain('Google');
  });

  test('deduplicates documents by ID', async () => {
    const { setupGoogleDocsContext } = await import('./google-docs-setup.js');

    const adf: ADFDocument = {
      version: 1,
      type: 'doc',
      content: [
        {
          type: 'paragraph',
          content: [
            {
              type: 'inlineCard',
              attrs: { url: 'https://docs.google.com/document/d/doc123/edit' },
            },
            {
              type: 'inlineCard',
              attrs: { url: 'https://docs.google.com/document/d/doc123/view' }, // Same doc
            },
          ],
        },
      ],
    };

    // This test will validate deduplication logic
    // The actual API calls are mocked, so we test the orchestration
    await setupGoogleDocsContext({
      epicAdf: adf,
      googleClient: mockGoogleClient,
      generateText: mockGenerateText,
    });

    // Should only process one document (deduplicated)
    // Note: This will fail initially until implementation is complete
    // which is expected in TDD - tests are written first
  });
});
